const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./connection'); 

const app = express();


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static('public')); 


app.get('/', (req, res) => {
    connection.query('SELECT * FROM usuarios', (err, results) => {
        if (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios');
        }
        res.render('index', { usuarios: results }); 
    });
});


app.get('/create', (req, res) => {
    res.render('create'); 
});


app.post('/create', (req, res) => {
    const { nombre, correo, numero_cuenta, escuela } = req.body;

 
    if (!nombre || !correo || !numero_cuenta || !escuela) {
        return res.status(400).send('Todos los campos son obligatorios');
    }

    const query = 'INSERT INTO usuarios (nombre, correo, numero_cuenta, escuela) VALUES (?, ?, ?, ?)';
    connection.query(query, [nombre, correo, numero_cuenta, escuela], (err) => {
        if (err) {
            console.error('Error al agregar usuario:', err);
            return res.status(500).send('Error al agregar usuario');
        }
        res.redirect('/'); 
    });
});


app.get('/edit/:id', (req, res) => {
    const { id } = req.params;

    const query = 'SELECT * FROM usuarios WHERE id = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error al obtener usuario para edición:', err);
            return res.status(500).send('Error al obtener usuario');
        }

        if (results.length === 0) {
            return res.status(404).send('Usuario no encontrado');
        }

        res.render('edit', { usuario: results[0] }); 
    });
});


app.post('/edit/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, correo, numero_cuenta, escuela } = req.body;

    if (!nombre || !correo || !numero_cuenta || !escuela) {
        return res.status(400).send('Todos los campos son obligatorios');
    }

    const query = 'UPDATE usuarios SET nombre = ?, correo = ?, numero_cuenta = ?, escuela = ? WHERE id = ?';
    connection.query(query, [nombre, correo, numero_cuenta, escuela, id], (err) => {
        if (err) {
            console.error('Error al actualizar usuario:', err);
            return res.status(500).send('Error al actualizar usuario');
        }
        res.redirect('/'); 
    });
});


app.get('/delete/:id', (req, res) => {
    const { id } = req.params;

    const query = 'DELETE FROM usuarios WHERE id = ?';
    connection.query(query, [id], (err) => {
        if (err) {
            console.error('Error al eliminar usuario:', err);
            return res.status(500).send('Error al eliminar usuario');
        }
        res.redirect('/'); 
    });
});


connection.query('SELECT 1', (err) => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        process.exit(1); 
    }
    console.log('Conexión a la base de datos verificada');
});


const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
